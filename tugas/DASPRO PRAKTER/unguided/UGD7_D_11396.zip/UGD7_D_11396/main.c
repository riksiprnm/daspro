#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>

void menu();
void setJmlTebak(int *jmlTebakan, int rentang);
void setRentangTebak(int *min, int *max, int *rentang, int jmlTebakan);
void tampil(int jmlTebak, int min, int max);
void tebakAngka(int *tebak1, int *tebak2, int *kunci, int max, int min, int jmlTebak);
int main(int argc, char *argv[]) {

	srand(time(NULL));

	int pil;
	int jmlTebakan=1;
	int minRange=0, maxRange=10;
	int tebakan1,tebakan2;
	int rentang=11;
	int angkaKunci;
	int selisih;

	do{
		system("cls");
		menu();
		printf("\n>>> "); scanf("%d", &pil);
		switch (pil){
		case 1:
			printf("\n\t--=== Set Jumlah Tebakan ===--\n");
			setJmlTebak(&jmlTebakan, rentang);
			printf("\n\t[*] Jumlah Tebakan Berhasil di Update");
		break;
		
		case 2:
			printf("\n\t--=== Set Rentang Permainan ===--\n");
			setRentangTebak(&minRange, &maxRange, &rentang, jmlTebakan);
			printf("\n\t[*] Berhasil Update Rentang Permainan");
		break;

		case 3:
			system("cls");
			printf("\n   --=== Let's Play The Game ===--\n");
			tampil(jmlTebakan,minRange,maxRange);
			printf("\n\n   --===========================--\n");
			tebakAngka(&tebakan1,&tebakan2, &angkaKunci,maxRange,minRange, jmlTebakan);
		break;

		case 0:
			printf("\n\tKeluar dari program . . .");
		break;

		default:
			printf("\n\t[!] Menu tidak tersedia");
		break;
		}
		getch();
	}while(pil!=0);
	
	return 0;
}

void menu(){
	printf("\n\t\t--=== UGD Prosedur 1 ===--\n");
	printf("\n[1] Set Jumah Tebakan");
	printf("\n[2] Set Rentang Permainan");
	printf("\n[3] Mulai Permainan");
	printf("\n[0] Exit");
}
void setJmlTebak(int *jmlTebakan, int rentang){
	do{
		printf("\nInput Jumlah Tebakan : "); scanf("%d", jmlTebakan);
		if(*jmlTebakan<1){
			printf("\n\t[!] Jumlah tebakan tidak boleh kurang dari 1\n");
		}else if(*jmlTebakan>rentang){
			printf("\n\t[!] Jumlah Tebakan tidak boleh lebih dari Rentang Permainan\n");
		}
	}while(*jmlTebakan<1 || *jmlTebakan>rentang);
}
void setRentangTebak(int *min, int *max, int *rentang, int jmlTebakan){
	do{
		printf("\nInput rentang max: "); scanf("%d", max);
		printf("\nInput rentang min: "); scanf("%d", min);
		*rentang= (*max)-(*min)+1;
		if(*min > *max){
			printf("\n\t[!] Rentang Invalid\n");
		}else if(*rentang<=jmlTebakan){
			printf("\n\t[!] Rentang Tidak Boleh < Jumlah Tebakan\n");
		}
	}while(*min>*max || *rentang<=jmlTebakan);
}

void tampil(int jmlTebak, int min, int max){
	printf("\n\tJumlah Tebakan : %d", jmlTebak);
	printf("\n\tMax Range      : %d", max);
	printf("\n\tMin Range      : %d", min);
}

void tebakAngka(int *tebak1, int *tebak2, int *kunci, int max, int min, int jmlTebak){
	int temp;
	int keberapa=0;
	int i=0;
	temp=jmlTebak;
	*kunci= (rand()% (max-min+1)+min);
	do{
		printf("\nTebak angka: "); scanf("%d", tebak1);
		keberapa++;
		if(i>=1){
			if(*tebak1==*kunci){
			break;
			}else if(abs(*tebak1-*kunci)<abs(*tebak2-*kunci)){
				printf("\n[~] Semakin Dekat\n");
			}else if(abs(*tebak1-*kunci)>abs(*tebak2-*kunci)){
				printf("\n[~] Semakin Jauh\n");
			}else if( abs(*tebak1-*kunci) == abs(*tebak2-*kunci)){
				printf("\n[~] Jarak Sama\n");
			}
		}
		i++;
		*tebak2=*tebak1;
		temp--;
	}while(temp>0);
	if(*tebak1==*kunci){
		printf("\n\n\t[*] Tebakan Kamu Benar !");
		printf("\n\tNilai tebakan %d", *kunci);
		printf("\n\tBenar di tebakan ke-%d", keberapa);
	}else{
		printf("\n\n\t[!] Kamu Gagal");
		printf("\n\tNilai tebakan %d", *kunci);
	}
	
}