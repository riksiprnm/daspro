#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef char string[50];

void cekLogin(string user, string pass, int *login);
void pengurangan(int *hasil, int pengurang);
void menu(int jmlA, int jmlB, int jmlC, int jmlX, int jmlY);

int hargaA=5000, hargaB=7500, hargaC=10000, hargaX=25000, hargaY=30000;
int main(int argc, char *argv[]) {
	string user, pass;
	string nama, no_tlp, tglDatang, jamDatang;
	string tali;
	int cekPembeli=0, cekPembelian=0, cekData=0;
	int toleransi=3;
	int login=0;
	int pil;
	int jmlA=50, jmlB=50, jmlC=50, jmlX=100, jmlY=100;
	int beliA, beliB, beliC, beliX, beliY;
	string nik, pekerjaan, alamat;
	do{
		system("cls");
		printf("\n\t\t--=== LOGIN ===--\n");
		printf("\n\tTolerasi: %d", toleransi);
		printf("\n\tUsername: "); fflush(stdin); gets(user);
		printf("\tpassword: "); fflush(stdin); gets(pass);
		cekLogin(user,pass,&login);
		if(login==1){
			do{
				system("cls");
				printf("\n\t\t--=== MENU ===--\n");
				menu(jmlA,jmlB,jmlC,jmlX,jmlY);
				printf("\n\t>>> "); scanf("%d", &pil);
				switch (pil){
				case 1:
					if(cekPembeli==0){
						printf("\n\t\t-- Input Pembeli --\n");
						printf("\n\tNama: "); fflush(stdin); gets(nama);
						while(strlen(nama)==0){
							printf("\n\t\t[!] Nama tidak boleh kosong");
							printf("\n\tNama: "); fflush(stdin); gets(nama);
						}
						printf("\n\tNo. Telp: "); fflush(stdin); gets(no_tlp);
						while(strlen(no_tlp)==0){
							printf("\n\t\t[!] Nomer telepon tidak boleh kosong");
							printf("\n\tNo. Telp: "); fflush(stdin); gets(no_tlp);
						}
						printf("\n\tTanggal Kedatangan: "); fflush(stdin); gets(tglDatang);
						while(strlen(tglDatang)!=10){
							printf("\n\t\t[!] Tanggal salah");
							printf("\n\tTanggal Kedatangan: "); fflush(stdin); gets(tglDatang);
						}
						printf("\n\tJam Kedatangan: "); fflush(stdin); gets(jamDatang);
						while(strlen(jamDatang)!=8){
							printf("\n\t\t[!] Jam salah");
							printf("\n\tJam Kedatangan: "); fflush(stdin); gets(jamDatang);
						}
						printf("\n\t\tBerhasil input data...");
						cekPembeli=1;

					}else{
						printf("\n\t\t[!] Data Pembeli sudah terinput!");
					}
				break;
				case 2:
					if(cekPembeli==1){
						printf("\n\t\t-- Input Pembelian\n");
						printf("\n\tJenis tali yang ingin dibeli (A/B/C/X/Y) :"); fflush(stdin); gets(tali);
						
						if(strcmpi(tali,"a")==0){
							if(jmlA>0){
								printf("\n\tJumlah tali yang ingin dibeli (m): "); scanf("%d", &beliA);
								while(beliA<=0 || beliA>jmlA){
									if(beliA<=0){
										printf("\n\t[!] Jumlah yang dibeli tidak boleh kurang dari sama dengan 0");
									}else if(beliA>jmlA){
										printf("\n\t[!] Jumlah yang dibeli tidak boleh melebihi persediaan");
									}
									printf("\n\tJumlah tali yang ingin dibeli (m): "); scanf("%d", &beliA);
								}
								pengurangan(&jmlA,beliA);
								printf("\n\tBerhasil input pembelian");
							}else{
								printf("\n\t[!] Persediaan habis");
							}
						}else if(strcmpi(tali,"b")==0){
							if(jmlB>0){
								printf("\n\tJumlah tali yang ingin dibeli (m): "); scanf("%d", &beliB);
								while(beliB<=0 || beliB>jmlB){
									if(beliB<=0){
										printf("\n\t[!] Jumlah yang dibeli tidak boleh kurang dari sama dengan 0");
									}else if(beliB>jmlB){
										printf("\n\t[!] Jumlah yang dibeli tidak boleh melebihi persediaan");
									}
									printf("\n\tJumlah tali yang ingin dibeli (m): "); scanf("%d", &beliB);
								}
								pengurangan(&jmlB,beliB);
								printf("\n\tBerhasil input pembelian");
							}else{
								printf("\n\t[!] Persediaan habis");
							}
							
						}else if(strcmpi(tali,"c")==0){
							if(jmlC>0){
								printf("\n\tJumlah tali yang ingin dibeli (m): "); scanf("%d", &beliC);
								while(beliC<=0 || beliC>jmlC){
									if(beliC<=0){
										printf("\n\t[!] Jumlah yang dibeli tidak boleh kurang dari sama dengan 0");
									}else if(beliC>jmlC){
										printf("\n\t[!] Jumlah yang dibeli tidak boleh melebihi persediaan");
									}
									printf("\n\tJumlah tali yang ingin dibeli (m): "); scanf("%d", &beliC);
								}
								pengurangan(&jmlC,beliC);
								printf("\n\tBerhasil input pembelian");
							}else{
								printf("\n\t[!] Persediaan habis");
							}
						}else if(strcmpi(tali,"x")==0){
							if(jmlX>0){
								printf("\n\tJumlah tali yang ingin dibeli (m): "); scanf("%d", &beliX);
								while(beliX<=0 || beliX>jmlX){
									if(beliX<=0){
										printf("\n\t[!] Jumlah yang dibeli tidak boleh kurang dari sama dengan 0");
									}else if(beliX>jmlX){
										printf("\n\t[!] Jumlah yang dibeli tidak boleh melebihi persediaan");
									}
									printf("\n\tJumlah tali yang ingin dibeli (m): "); scanf("%d", &beliX);
								}
								pengurangan(&jmlX, beliX);
								if(cekData==0){
									printf("\n\tNIK: "); fflush(stdin); gets(nik);
									while(strlen(nik)!=16){
										printf("\n\t[!] NIK salah");
										printf("\n\tNIK: "); fflush(stdin); gets(nik);
									}
									printf("\n\tPekerjaan: "); fflush(stdin); gets(pekerjaan);
									while(strlen(pekerjaan)==0){
										printf("\n\t[!] Pekerjaan tidak boleh kosong");
										printf("\n\tPekerjaan: "); fflush(stdin); gets(pekerjaan);
									}
									printf("\n\tAlamat: "); fflush(stdin); gets(alamat);
									while(strlen(alamat)==0){
										printf("\n\t[!] Alamat tidak boleh kosong");
										printf("\n\tAlamat: "); fflush(stdin); gets(alamat);
									}
									cekData=1;
								}
								printf("\n\tBerhasil input pembelian");
							}else{
								printf("\n\t[!] Persediaan habis");
							}
							
						}else if(strcmpi(tali,"y")==0){
							if(jmlY>0){
								printf("\n\tJumlah tali yang ingin dibeli (m): "); scanf("%d", &beliY);
								while(beliY<=0 || beliY>jmlY){
									if(beliY<=0){
										printf("\n\t[!] Jumlah yang dibeli tidak boleh kurang dari sama dengan 0");
									}else if(beliY>jmlY){
										printf("\n\t[!] Jumlah yang dibeli tidak boleh melebihi persediaan");
									}
									printf("\n\tJumlah tali yang ingin dibeli (m): "); scanf("%d", &beliY);
								}
								pengurangan(&jmlY, beliY);
								if(cekData==0){
									printf("\n\tNIK: "); fflush(stdin); gets(nik);
									while(strlen(nik)!=16){
										printf("\n\t[!] NIK salah");
										printf("\n\tNIK: "); fflush(stdin); gets(nik);
									}
									printf("\n\tPekerjaan: "); fflush(stdin); gets(pekerjaan);
									while(strlen(pekerjaan)==0){
										printf("\n\t[!] Pekerjaan tidak boleh kosong");
										printf("\n\tPekerjaan: "); fflush(stdin); gets(pekerjaan);
									}
									printf("\n\tAlamat: "); fflush(stdin); gets(alamat);
									while(strlen(alamat)==0){
										printf("\n\t[!] Alamat tidak boleh kosong");
										printf("\n\tAlamat: "); fflush(stdin); gets(alamat);
									}
									cekData=1;
								}
								printf("\n\tBerhasil input pembelian");
							}else{
								printf("\n\t[!] Persediaan habis");
							}
							
						}else{
							printf("\n\t[!] Jenis tali tidak diketahui");
						}
						cekPembelian=1;
					}else{
						printf("\n\t[!] Belum input data pembeli");
					}
				break;

				case 3:
					if(cekPembeli==1 && cekPembelian==1){
						printf("\n\t\t-- Pembayaran --\n");
						printf("\n\tNama: %s", nama);
						printf("\n\tWaktu kedatangan: %s %s", tglDatang, jamDatang);
						printf("\n\t\t-- Rincian --\n");
						printf("\nTali A	|%d|	 |@Rp %d| Total: Rp %d",beliA,hargaA,beliA*hargaA);
						printf("\nTali B	|%d|	 |@Rp %d| Total: Rp %d",beliB,hargaB,beliB*hargaB);
						printf("\nTali C	|%d|	 |@Rp %d| Total: Rp %d",beliC,hargaC,beliC*hargaC);
						printf("\nTali X	|%d|	 |@Rp %d| Total: Rp %d",beliX,hargaX,beliX*hargaX);
						printf("\nTali Y	|%d|	 |@Rp %d| Total: Rp %d",beliY,hargaY,beliY*hargaY);
					}else if(cekPembelian==0 && cekPembeli==0){
						printf("\n\t[!] Input Data Pembeli dan Data Pembelian terlebih dahulu");
					}else if(cekPembelian==0){
						printf("\n\t[!] Input Data Pembelian terlebih dahulu");
					}

				break;

				case 4:
				break;

				case 0:
					printf("\n[~] Kembali ke halaman login...");
				break;
				default:
					printf("\n\t[!] Menu tidak tersedia");
				break;
				}
				getch();
			}while(pil!=0);
		}else if(login==-1){
			printf("\n\t[!]Username atau password salah!");
			pengurangan(&toleransi,1);
		}else if(login==0){
			break;
		}
		getch();
	}while(toleransi>0);
	printf("\n\tBerhasil keluar...");
	printf("\n\tMade Riksi Purnama Sadnya Agung - 210711396 - D");
	return 0;
}
void cekLogin(string user, string pass, int *login){
	if(strcmp(user,"Atma")==0 && strcmp(pass,"11396")==0){
		*login=1;
	}else if(strcmp(user,"0")==0 && strcmp(pass,"0")==0){
		*login=0;
	}else{
		*login=-1;
	}	
}
void pengurangan(int *hasil, int pengurang){
	*hasil=*hasil-pengurang;
}

void menu(int jmlA, int jmlB, int jmlC, int jmlX, int jmlY){
	printf("\n\tKetersediaan tali: ");
	printf("\n\t| %d Tali A | %d Tali B | %d Tali C | %d Tali X | %d Tali Y |\n", jmlA,jmlB,jmlC,jmlX,jmlY);
	printf("\n\t[1] Input Pembeli");
	printf("\n\t[2] Input Pembelian");
	printf("\n\t[3] Rincian");
	printf("\n\t[4] Reset Data");
	printf("\n\t[0] Logout");
}
